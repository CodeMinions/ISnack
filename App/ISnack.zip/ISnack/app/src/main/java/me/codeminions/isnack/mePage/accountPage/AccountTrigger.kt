package me.codeminions.isnack.mePage.accountPage

interface AccountTrigger {
    fun onTrigger()
}