package me.codeminions.isnack.snackDetails

import me.codeminions.common.app.DataBindingFragment
import me.codeminions.isnack.R
import me.codeminions.isnack.databinding.FragmentSnackCommentBinding

class SnackDetailCommentFragment : DataBindingFragment<FragmentSnackCommentBinding>() {

    override fun getContentLayoutId(): Int {
        return R.layout.fragment_snack_comment
    }




}