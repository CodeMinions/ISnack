package me.codeminions.common.widget

interface OnItemClickListener<T> {
    fun onItemClick(data :T)
}